/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI, Type } from "@google/genai";

document.addEventListener('DOMContentLoaded', () => {
  // Set the date we're counting down to
  const countDownDate = new Date('Feb 10, 2026 00:00:00').getTime();

  const daysEl = document.getElementById('days');
  const hoursEl = document.getElementById('hours');
  const minutesEl = document.getElementById('minutes');
  const secondsEl = document.getElementById('seconds');

  if (daysEl && hoursEl && minutesEl && secondsEl) {
    // Update the count down every 1 second
    const x = setInterval(function() {
      // Get today's date and time
      const now = new Date().getTime();

      // Find the distance between now and the count down date
      const distance = countDownDate - now;

      // Time calculations for days, hours, minutes and seconds
      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      // Display the result in the elements
      daysEl.innerText = String(days).padStart(2, '0');
      hoursEl.innerText = String(hours).padStart(2, '0');
      minutesEl.innerText = String(minutes).padStart(2, '0');
      secondsEl.innerText = String(seconds).padStart(2, '0');


      // If the count down is finished, write some text
      if (distance < 0) {
        clearInterval(x);
        document.querySelector('.countdown-timer')!.innerHTML = "<h2>The Expo is here!</h2>";
      }
    }, 1000);
  }

  // Live urgency message rotator
  const urgencyMessages = [
    "🔥 Limited early bird tickets remaining!",
    "🎟️ Tickets are selling fast!",
    "🎉 Over 500 educators have registered!",
    "⏰ Prices increase next week!",
    "🎤 New keynote speaker just announced!"
  ];
  let messageIndex = 0;
  const urgencyEl = document.getElementById('urgency-message');

  if (urgencyEl) {
    setInterval(() => {
      urgencyEl.classList.add('fade-out');

      setTimeout(() => {
        messageIndex = (messageIndex + 1) % urgencyMessages.length;
        urgencyEl.innerText = urgencyMessages[messageIndex];
        urgencyEl.classList.remove('fade-out');
      }, 500); // Corresponds to the CSS transition duration
    }, 4000); // Change message every 4 seconds
  }
  
  // --- Form Validation Helpers ---
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  const showError = (input: HTMLElement, message: string) => {
    const formGroup = input.parentElement;
    const errorElement = formGroup?.querySelector('.error-message');
    if (errorElement) {
      input.classList.add('invalid');
      errorElement.textContent = message;
    }
  };

  const clearError = (input: HTMLElement) => {
     const formGroup = input.parentElement;
     const errorElement = formGroup?.querySelector('.error-message');
     if (errorElement) {
      input.classList.remove('invalid');
      errorElement.textContent = '';
     }
  };


  // Contact Form Validation
  const contactForm = document.querySelector<HTMLFormElement>('.contact-form');
  if (contactForm) {
    const nameInput = document.getElementById('name') as HTMLInputElement;
    const emailInput = document.getElementById('email') as HTMLInputElement;
    const messageInput = document.getElementById('message') as HTMLTextAreaElement;

    const validateName = () => {
      if (nameInput.value.trim() === '') {
        showError(nameInput, 'Full name is required.');
        return false;
      }
      clearError(nameInput);
      return true;
    };

    const validateEmail = () => {
      const value = emailInput.value.trim();
      if (value === '') {
        showError(emailInput, 'Email address is required.');
        return false;
      }
      if (!emailRegex.test(value)) {
        showError(emailInput, 'Please enter a valid email address.');
        return false;
      }
      clearError(emailInput);
      return true;
    };

    const validateMessage = () => {
      if (messageInput.value.trim() === '') {
        showError(messageInput, 'Message cannot be empty.');
        return false;
      }
      clearError(messageInput);
      return true;
    };

    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const isNameValid = validateName();
      const isEmailValid = validateEmail();
      const isMessageValid = validateMessage();

      if (isNameValid && isEmailValid && isMessageValid) {
        alert('Form submitted successfully! (Just a demo)');
        contactForm.reset();
        clearError(nameInput);
        clearError(emailInput);
        clearError(messageInput);
      }
    });

    // Real-time validation listeners
    nameInput.addEventListener('input', validateName);
    emailInput.addEventListener('input', validateEmail);
    messageInput.addEventListener('input', validateMessage);
  }
  
  // Registration Form Logic
  const registrationForm = document.getElementById('registration-form') as HTMLFormElement;
  if (registrationForm) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const formContainer = document.querySelector('.registration-form-container');
    const nameInput = document.getElementById('reg-name') as HTMLInputElement;
    const emailInput = document.getElementById('reg-email') as HTMLInputElement;
    const institutionInput = document.getElementById('reg-institution') as HTMLInputElement;
    const roleInput = document.getElementById('reg-role') as HTMLInputElement;

    const validateRegName = () => {
      if (nameInput.value.trim() === '') {
        showError(nameInput, 'Full name is required.');
        return false;
      }
      clearError(nameInput);
      return true;
    };

    const validateRegEmail = () => {
      const value = emailInput.value.trim();
      if (value === '') {
        showError(emailInput, 'Email address is required.');
        return false;
      }
      if (!emailRegex.test(value)) {
        showError(emailInput, 'Please enter a valid email address.');
        return false;
      }
      clearError(emailInput);
      return true;
    };
    
    const validateRegInstitution = () => {
      if (institutionInput.value.trim() === '') {
        showError(institutionInput, 'Institution is required.');
        return false;
      }
      clearError(institutionInput);
      return true;
    };

    const validateRegRole = () => {
      if (roleInput.value.trim() === '') {
        showError(roleInput, 'Your role is required.');
        return false;
      }
      clearError(roleInput);
      return true;
    };


    registrationForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const isNameValid = validateRegName();
      const isEmailValid = validateRegEmail();
      const isInstitutionValid = validateRegInstitution();
      const isRoleValid = validateRegRole();

      if (isNameValid && isEmailValid && isInstitutionValid && isRoleValid) {
        const registrationData = {
          name: nameInput.value.trim(),
          email: emailInput.value.trim(),
          institution: institutionInput.value.trim(),
          role: roleInput.value.trim(),
          timestamp: new Date().toISOString()
        };

        try {
          // Save to local storage
          const existingRegistrations = JSON.parse(localStorage.getItem('expoRegistrations') || '[]');
          existingRegistrations.push(registrationData);
          localStorage.setItem('expoRegistrations', JSON.stringify(existingRegistrations));
          
          if(formContainer) {
             // 1. Show a loading state
              formContainer.innerHTML = `
                  <div class="registration-processing">
                      <h3>Processing your registration...</h3>
                      <p>Please wait while we confirm your spot and prepare your confirmation details.</p>
                      <div class="spinner"></div>
                  </div>
              `;

              // 2. Generate emails with Gemini
              try {
                  const { name, email, institution, role } = registrationData;
                  const thankYouPrompt = `Generate a friendly and welcoming "Thank you for registering" email for a person named "${name}". The event is the "Qatar Education Leadership Expo 2026". The email should have a clear subject line and a body. Mention that their spot is confirmed and they should look forward to an inspiring event. Keep it concise and professional. Respond with a JSON object containing "subject" and "body" keys.`;
                  const notificationPrompt = `Generate a new registration notification email for an administrator. The email should be addressed to abishsuresh01@gmail.com. It needs a clear subject line like "New Registration for Qatar Expo". The body should state that a new person has registered for the "Qatar Education Leadership Expo 2026". List the following details clearly:
- Name: ${name}
- Email: ${email}
- Institution: ${institution}
- Role: ${role}
Respond with a JSON object containing "subject" and "body" keys.`;

                  const emailSchema = {
                    type: Type.OBJECT,
                    properties: {
                      subject: { type: Type.STRING },
                      body: { type: Type.STRING },
                    },
                    required: ['subject', 'body'],
                  };

                  const [thankYouResponse, notificationResponse] = await Promise.all([
                      ai.models.generateContent({ 
                        model: 'gemini-2.5-flash', 
                        contents: thankYouPrompt,
                        config: { responseMimeType: "application/json", responseSchema: emailSchema } 
                      }),
                      ai.models.generateContent({ 
                        model: 'gemini-2.5-flash', 
                        contents: notificationPrompt,
                        config: { responseMimeType: "application/json", responseSchema: emailSchema }
                      })
                  ]);
                  
                  const thankYouEmail = JSON.parse(thankYouResponse.text);
                  const notificationEmail = JSON.parse(notificationResponse.text);
                  
                   // 3. Display success message with generated emails
                  formContainer.innerHTML = `
                      <div class="registration-success">
                          <h3>✅ Registration Confirmed!</h3>
                          <p>Your spot is secured. We've dispatched a confirmation to your email and a notification to our records. You can see the content of these communications below.</p>
                          
                          <div class="email-preview">
                            <div class="email-preview-header">
                              <h4>Confirmation Sent to ${email}</h4>
                              <span class="status-sent">Sent ✔</span>
                            </div>
                            <div class="email-content">
                                <strong>Subject:</strong> ${thankYouEmail.subject}
                                <hr>
                                <pre>${thankYouEmail.body}</pre>
                            </div>
                          </div>

                          <div class="email-preview">
                            <div class="email-preview-header">
                              <h4>Admin Notification Logged</h4>
                              <span class="status-sent">Sent ✔</span>
                            </div>
                            <div class="email-content">
                                 <strong>Subject:</strong> ${notificationEmail.subject}
                                 <hr>
                                 <pre>${notificationEmail.body}</pre>
                            </div>
                          </div>
                      </div>
                  `;

              } catch (genError) {
                  console.error('Failed to generate email content:', genError);
                  // Fallback to the original success message if Gemini fails
                  formContainer.innerHTML = `
                      <div class="registration-success">
                          <h3>🎉 Thank You for Registering!</h3>
                          <p>Your spot is confirmed. We've sent a confirmation to your email. See you there!</p>
                          <p class="error-note">Note: Could not generate email preview.</p>
                      </div>
                  `;
              }
          }
          
        } catch (error) {
          console.error('Failed to save registration to local storage:', error);
          alert('An error occurred while saving your registration. Please try again.');
        }
      }
    });

    nameInput.addEventListener('input', validateRegName);
    emailInput.addEventListener('input', validateRegEmail);
    institutionInput.addEventListener('input', validateRegInstitution);
    roleInput.addEventListener('input', validateRegRole);
  }
  
  // Scroll Animation Observer
  const animatedSections = document.querySelectorAll('.animate-on-scroll');
  if (animatedSections.length > 0) {
    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1 // Trigger when 10% of the element is visible
    });

    animatedSections.forEach(section => {
      observer.observe(section);
    });
  }
});